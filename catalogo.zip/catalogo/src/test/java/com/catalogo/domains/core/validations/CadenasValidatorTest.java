package com.catalogo.domains.core.validations;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CadenasValidatorTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
